package com.ucr.crawler;

import java.util.Vector;

public class homecrawler {

	/*
	 * author: Minghao Xu
	 * parameters:
	 * 1. type: "crawler" or "parser"
	 * 2. record type: "rent" or "sale"
	 * 3. group id: range from 1 to 5
	 * 4. number of threads
	 * 5. life of browser: range from 10 to 1000 
	 *    (destroy current browser and create a new one after visit assigned number of pages)
	 *    larger # threads => smaller life
	 *   smaller # threads => larger  life
	 */
	private static final String[] GROUP_ONE = { "DC", "AR", "MS", "ND", "SC", "MI", "IN", "KS", "MD", "NY" };
	private static final String[] GROUP_TWO = { "CO", "NC", "MT", "FL", "LA", "ME", "NJ", "TN", "NM", "AZ" };
	private static final String[] GROUP_THREE = { "VA", "SD", "VT", "PR", "UT", "WY", "CT", "HI", "WI", "NH" };
	private static final String[] GROUP_FOUR = { "DE", "RI", "TX", "MO", "KY", "WV", "PA", "OK", "AL", "NE" };
	private static final String[] GROUP_FIVE = { "OR", "AK", "CA", "WA", "MA", "IL", "MN", "GA", "IA", "OH", "NV", "ID"};

	public static void main(String args[]) {

		String type = args[0];
		String recordType = args[1];
		int threadNum = Integer.parseInt(args[3]);
		if (type.equals("crawler")) {
			int n = Integer.parseInt(args[2]);
			int life = Integer.parseInt(args[4]);
			String[] states = {};
			if (n == 1) {
				states = GROUP_ONE;
			} else if (n == 2){
				states = GROUP_TWO;
			} else if (n == 3) {
				states = GROUP_THREE;
			} else if (n == 4) {
				states = GROUP_FOUR;
			} else if (n == 5) {
				states = GROUP_FIVE;
			} else {
				System.err.println("input wrong group id!");
				System.exit(0);
			}
			
			if(threadNum == 1){
				// do not do multi-threads
				for(String str1 : states){
					Worker.crawlhomes(str1, recordType,life);
				}
			}else{
				// do multi-threads
				for (int i = 0; i < threadNum; i++) {
					Vector<String> currentStates = new Vector<String>();
					int bucket = states.length / threadNum;
					if(i != threadNum - 1){
						for (int j = i * bucket; j < (i+1)*bucket; j++) {
							currentStates.add(states[j]);
						}
					}else {
						for (int j = i * bucket; j < states.length; j++) {
							currentStates.add(states[j]);
						}
					}
					Worker worker = new Worker(currentStates, recordType,life);
					Thread thread = new Thread(worker);
					thread.start();
				}
			}
		}
		else if (type.equals("parser")) {
			
			Parser parser = new Parser();
			
			parser.runParser();
		
			
		}
	}
}
//package com.ucr.crawler;
//
//import java.io.BufferedWriter;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.sql.Timestamp;
//import java.sql.Types;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Vector;
//import java.util.concurrent.TimeUnit;
//
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.firefox.FirefoxBinary;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxOptions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//public class homecrawler {
//
//	public static void main(String args[])
//			throws InterruptedException, ClassNotFoundException, SQLException, ParseException {
//		// String place = "anvik-ak";
//		// String place = "chicago-il";
//		// String place = "riverside-ca";
//		// crawlhomes(place);
//
//		String str1 = null;
//
//		String n = args[0];
//		if (n.equals("one")) {
//			for (int i = 1; i <= 30; ++i) {
//
//				if (i == 1) {
//					str1 = "DC";
//					System.out.println("DC");
//				}
//
//				else if (i == 2) {
//					str1 = "OH";
//					System.out.println("OH");
//				}
//
//				else if (i == 3) {
//					str1 = "MI";
//					System.out.println("MI");
//				}
//
//				else if (i == 4) {
//					str1 = "IN";
//					System.out.println("IN");
//				}
//
//				else if (i == 5) {
//					str1 = "KS";
//					System.out.println("KS");
//				}
//
//				else if (i == 6) {
//					str1 = "MD";
//				}
//
//				else if (i == 7) {
//					str1 = "CO";
//				}
//
//				else if (i == 8) {
//					str1 = "MT";
//				}
//
//				else if (i == 9) {
//					str1 = "UT";
//				}
//
//				else if (i == 10) {
//					str1 = "WY";
//				}
//
//				crawlhomes(str1);
//			}
//
//		}
//
//		if (n.equals("two")) {
//			for (int i = 1; i <= 10; ++i) {
//
//				if (i == 1) {
//					str1 = "TX";
//				}
//
//				else if (i == 2) {
//					str1 = "MO";
//				}
//
//				else if (i == 3) {
//					str1 = "KY";
//				}
//
//				else if (i == 4) {
//					str1 = "WV";
//				}
//
//				else if (i == 5) {
//					str1 = "AL";
//				}
//
//				else if (i == 6) {
//					str1 = "NE";
//				}
//
//				else if (i == 7) {
//					str1 = "MS";
//				}
//
//				else if (i == 8) {
//					str1 = "ND";
//				}
//
//				else if (i == 9) {
//					str1 = "CT";
//				}
//
//				else if (i == 10) {
//					str1 = "HI";
//				}
//
//				crawlhomes(str1);
//			}
//
//		}
//
//		if (n.equals("three")) {
//			for (int i = 1; i <= 10; ++i) {
//
//				if (i == 1) {
//					str1 = "NY";
//				}
//
//				else if (i == 2) {
//					str1 = "FL";
//				}
//
//				else if (i == 3) {
//					str1 = "NC";
//				}
//
//				else if (i == 4) {
//					str1 = "OK";
//				}
//
//				else if (i == 5) {
//					str1 = "AR";
//				}
//
//				else if (i == 6) {
//					str1 = "LA";
//				}
//
//				else if (i == 7) {
//					str1 = "ME";
//				}
//
//				else if (i == 8) {
//					str1 = "SD";
//				}
//
//				else if (i == 9) {
//					str1 = "VT";
//				}
//
//				else if (i == 10) {
//					str1 = "NV";
//				}
//
//				crawlhomes(str1);
//			}
//
//		}
//
//		if (n.equals("four")) {
//			for (int i = 1; i <= 10; ++i) {
//				if (i == 1) {
//					str1 = "CA";
//				}
//
//				else if (i == 2) {
//					str1 = "IA";
//				}
//
//				else if (i == 3) {
//					str1 = "VA";
//				}
//
//				else if (i == 4) {
//					str1 = "GA";
//				}
//
//				else if (i == 5) {
//					str1 = "WA";
//				}
//
//				else if (i == 6) {
//					str1 = "MA";
//				}
//
//				else if (i == 7) {
//					str1 = "OR";
//				}
//
//				else if (i == 8) {
//					str1 = "AK";
//				}
//
//				else if (i == 9) {
//					str1 = "ID";
//				}
//
//				else if (i == 10) {
//					str1 = "PR";
//				}
//
//				crawlhomes(str1);
//			}
//
//		}
//
//		if (n.equals("five")) {
//			for (int i = 1; i <= 10; ++i) {
//
//				if (i == 1) {
//					str1 = "IL";
//				}
//
//				else if (i == 2) {
//					str1 = "MN";
//				}
//
//				else if (i == 3) {
//					str1 = "WI";
//				}
//
//				else if (i == 4) {
//					str1 = "NJ";
//				}
//
//				else if (i == 5) {
//					str1 = "TN";
//				}
//
//				else if (i == 6) {
//					str1 = "SC";
//				}
//
//				else if (i == 7) {
//					str1 = "NM";
//				}
//
//				else if (i == 8) {
//					str1 = "AZ";
//				}
//
//				else if (i == 9) {
//					str1 = "NH";
//				}
//
//				else if (i == 10) {
//					str1 = "DE";
//				}
//
//				crawlhomes(str1);
//			}
//
//		}
//		if (n.equals("six")) {
//			for (int i = 1; i <= 2; ++i) {
//
//				if (i == 1) {
//					str1 = "RI";
//				}
//
//				else if (i == 2) {
//					str1 = "PA";
//				}
//
//				crawlhomes(str1);
//
//			}
//
//		}
//	}
//
//	// for sever:v75 use only
//	private static Connection newConnection() throws ClassNotFoundException, SQLException {
//		Class.forName("com.mysql.jdbc.Driver");
//		String urldb = "jdbc:mysql://localhost/homeDB";
//		String user = "mxu054";
//		String password = "123456";
//		Connection conn = DriverManager.getConnection(urldb, user, password);
//		return conn;
//	}
//
//	 //for local window10 use only
////	private static Connection newConnection() throws ClassNotFoundException, SQLException {
////		String driver = "com.mysql.cj.jdbc.Driver";
////		String url = "jdbc:mysql://localhost:3306/home_data?&useSSL=false&serverTimezone=UTC";
////		String username = "root";
////		String password = "123456";
////		Connection conn = null;
////
////		Class.forName(driver);
////		conn = DriverManager.getConnection(url, username, password);
////		if (!conn.isClosed())
////			System.out.println("Database accessed！");
////		return conn;
////	}
//
//
//	public static void crawlhomes(String str1) {
//		System.out.println(str1);
//		try {
//			Connection connection1 = newConnection();
//			Statement statement = null;
//			ResultSet resultSet = null;
//		
//			statement = connection1.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
//					java.sql.ResultSet.CONCUR_READ_ONLY);
//			statement.setFetchSize(Integer.MIN_VALUE);
//		
//			resultSet = statement
//					.executeQuery("SELECT distinct(city),state_code from cities_extended WHERE state_code='" + str1
//							+ "' order by state_code");
//			// city list of one state
//			Vector<String> cities = new Vector<String>();
//			while (resultSet.next()) {
//				// we need to use '-' to replace ' '
//				cities.add(resultSet.getString("city").toLowerCase().trim().replace(" ", "-"));
//			}
//			connection1.close();
//			
//			//System.setProperty("webdriver.gecko.driver", "tools\\geckodriver.exe");
//			System.setProperty("webdriver.gecko.driver", "geckodriver");
//			
//			FirefoxOptions  firefoxOptions = new FirefoxOptions();
//			firefoxOptions.addArguments("--headless");
//			WebDriver driver = new FirefoxDriver(firefoxOptions);
//			
//			
//			
//			
//			boolean driverclosed = false;
//			String stateCode = str1.toLowerCase();
//			for (String city : cities) {
//				
//				// this try to catch firefox crash error
//				try {
//					if (driverclosed) {
//						driver = new FirefoxDriver(firefoxOptions);
//						driverclosed = false;
//					}
//					// get total number of pages
//					int totalPages = 1;
//					Document document = null;
//					String page = null;
//					driver.get("https://www.homes.com/" + city + "-" + stateCode + "/homes-for-rent/");
//					Thread.sleep((int)(500+Math.random()*500));
//					(new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(
//							By.cssSelector("h1.title")));
//					page = driver.getPageSource();
//					document = Jsoup.parse(page);
//					if (!document.select("li[data-tl-object=SR-PaginationNumber]").isEmpty()) {
//						for (int i = 0; i < document.select("li[data-tl-object=SR-PaginationNumber]").size(); i++) {
//							int now = Integer.parseInt(document.select("li[data-tl-object=SR-PaginationNumber]").get(i)
//									.text().replaceAll("[^0-9]", ""));
//							if (now > totalPages)
//								totalPages = now;
//						}
//					}
//		
//					Connection connection = newConnection();
//		
//					document = null;
//					page = null;
//					Vector<String> homeDetailLinks = new Vector<String>();
//		
//					boolean is_refreshed = false;
//					boolean is_second_access = false;
//		
//					for (int i = 1; i <= totalPages; i++) {
//						try {
//							if (is_second_access) {
//								is_second_access = false;
//								is_refreshed = false;
//							}
//							driver.get("https://www.homes.com/" + city + "-" + stateCode + "/homes-for-rent/p" + i);
//							Thread.sleep((int)(500+Math.random()*500));
//							(new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(
//									By.cssSelector("h1.title")));
////							(new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
////									"/html/body/div[1]/div/main/div[1]/section/div/section[2]/section[1]/section/div/div[1]/div[1]/h1")));
//							page = null;
//							document = null;
//		
//							page = driver.getPageSource();
//							document = Jsoup.parse(page);
//		
//							// there exits results
//							Elements links = document.getElementsByTag("a");
//							for (Element link : links) {
//								String linkhref = link.attr("href");
//								// ignore ads and other useless links
//								if (linkhref.startsWith("/property/")&&linkhref.endsWith("#listing_status=FOR_RENT")) {
//									
//									// if current link is added into vector, check next
//									if (homeDetailLinks.contains("https://www.homes.com" + linkhref)) {
//										continue;
//									}
//									boolean flag = false;
//									statement = null;
//									resultSet = null;
//									statement = connection.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
//											java.sql.ResultSet.CONCUR_READ_ONLY);
//									statement.setFetchSize(Integer.MIN_VALUE);
//									resultSet = statement
//											.executeQuery("SELECT count(*) as num from homes_2018 WHERE home_url='"
//													+ "https://www.homes.com" + linkhref + "'");
//									while (resultSet.next()) {
//										int count = resultSet.getInt("num");
//										if (count != 0)
//											flag = true;
//									}
//									if (!flag) {
//										homeDetailLinks.add("https://www.homes.com" + linkhref);
//									}
//		
//								}
//							}
//		
//							if (is_refreshed)
//								is_refreshed = false;
//		
//						} catch (Exception e) {
//							e.printStackTrace();
//							if (!is_refreshed) {
//								is_refreshed = true;
//								//driver.navigate().refresh();
//								i--;
//							} else {
//								is_second_access = true;
//							}
//						}
//		
//					}
//					
//					connection.close();
//		
//					// to give not-found-page one more chance
//					is_refreshed = false;
//					is_second_access = false;
//		
//					for (int k = 0; k < homeDetailLinks.size(); k++) {
//						try {
//							if (is_second_access) {
//								is_refreshed = false;
//								is_second_access = false;
//							}
//							if (is_refreshed) {
//								is_second_access = true;
//							}
//							String home_url = homeDetailLinks.get(k);
//							driver.get(home_url);
//		
//							Thread.sleep((int)(500+Math.random()*500));
//							(new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(
//									By.cssSelector("h2.property-info__title:nth-child(2)")));
//							page = driver.getPageSource();
//							
//		
//							// download page source codes
//							if (page != null) {
//								FileWriter fileWriter = new FileWriter("source_codes/" + city + "_" + stateCode + "_"
//											+ k + ".txt", true);
//								BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
//								bufferedWriter.write("" + page);
//								bufferedWriter.close();
//								fileWriter.close();
//							}
//		
//						} 
//						catch (Exception e) {
//							// TODO: handle exception
//								e.printStackTrace();
//								if (!is_refreshed) {
//									//driver.navigate().refresh();
//									is_refreshed = true;
//									k = (k != 0) ? --k : k;
//								} else {
//									driver.quit();
//									driver = new FirefoxDriver(firefoxOptions);
//								}
//						}
//					}
//				} catch (Exception e) {
//					// TODO: handle exception
//					e.printStackTrace();
//					driver.quit();
//					driverclosed = true;
//				}
//			}
//			
//			driver.quit();
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//}
