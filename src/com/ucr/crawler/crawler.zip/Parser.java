package com.ucr.crawler;

import java.io.File;
import java.util.Vector;

public class Parser {

	public void runParser(){
		String path = "source_codes";
		File fileObj = new File(path);
		File[] files = fileObj.listFiles();
		Vector<Vector<File>> lists = new Vector<Vector<File>>();
		for (int i = 0; i < 3; i++) {
			lists.add(new Vector<File>());
		}
		int index = 0;
		for(File file : files){
			lists.get(index % 3).add(file);
			index++;
		}
		
		ParserWorker worker1 = new ParserWorker(lists.get(0));
		ParserWorker worker2 = new ParserWorker(lists.get(1));
		ParserWorker worker3 = new ParserWorker(lists.get(2));
//		ParserWorker worker4 = new ParserWorker(lists.get(3));
//		ParserWorker worker5 = new ParserWorker(lists.get(4));
		
		Thread thread1 = new Thread(worker1);
		Thread thread2 = new Thread(worker2);
		Thread thread3 = new Thread(worker3);
//		Thread thread4 = new Thread(worker4);
//		Thread thread5 = new Thread(worker5);
		
		thread1.start();
		thread2.start();
		thread3.start();
//		thread4.start();
//		thread5.start();
		
		
	}
}
